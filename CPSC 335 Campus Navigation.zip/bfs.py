from collections import deque

# Function to perform BFS to find the shortest path in a given city map
def bfs(campus_graph, start, destination, wheelchair=False):
    # Queue for BFS paths to explore
    queue = deque([(start, 0, [start])])
    # Set to track visited intersections
    visited = set()

    # Continue BFS until all paths are explored
    while queue:
        # Dequeue the current path to explore
        current_intersection, total_weight, path = queue.popleft()

        # Check if we have reached the destination
        if current_intersection == destination:
            print(total_weight, path)
            return total_weight, path
        
        # If not visited, explore neighbors
        if current_intersection not in visited:
            visited.add(current_intersection)

            # Add all the neighbors to the queue as a new path
            for neighbor, edge_info in campus_graph[current_intersection].items():
                weight = edge_info['weight']
                accessible = edge_info.get('wheelchair', 'No')  # Check wheelchair accessibility
                
                # If wheelchair accessibility is required, skip non-accessible paths
                if wheelchair and accessible != 'Yes':
                    continue  # Skip non-accessible paths

                # Calculate the total weight of the path
                new_total_weight = total_weight + weight
                new_path = list(path)
                new_path.append(neighbor)
                queue.append((neighbor, new_total_weight, new_path))

    # If no path found, return None
    print("No path found from", start, "to", destination)
    return 0, None
