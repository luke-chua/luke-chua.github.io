def dfs(campus_graph, start, destination, wheelchair=False):
    # Initialize the path and visited set
    visited = set()
    stack = [(start, 0, [start])]

    while stack:
        current_intersection, total_weight, path = stack.pop()
        
        # If the current node is the destination, return the path as the result (exit)
        if current_intersection == destination:
            print(total_weight, path)
            return total_weight, path
        
        # Explore all the neighboring nodes of the current node
        if current_intersection not in visited:
            visited.add(current_intersection)
            
            for neighbor, edge_info in campus_graph[current_intersection].items():
                weight = edge_info['weight']
                accessible = edge_info.get('wheelchair', 'No')  # Get the wheelchair accessibility
                
                # If wheelchair accessibility is required, skip non-accessible paths
                if wheelchair and accessible != 'Yes':
                    continue  # Skip non-accessible paths
                
                # Calculate the total weight of the path
                new_total_weight = total_weight + weight
                new_path = path + [neighbor]
                
                # Push the neighbor and the updated path onto the stack
                stack.append((neighbor, new_total_weight, new_path))

    # If no path is found, return None
    print("No path found from", start, "to", destination)
    return None, None
