from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from random import randrange
from tkinter import ttk, messagebox
import bfs
import dfs
import dijkstra
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
import networkx as nx
import nodeinformation
import tkinter as tk

class CampusNavigationApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Smart Campus Navigation System")
        self.root.state('zoomed')  # Maximizes the window
        self.root.configure(bg="#e6e6e6")

        # Styling
        self.style = ttk.Style()
        self.style.theme_use("clam")
        self.style.configure(".", background="#e6e6e6", foreground="black")  # Set default bg and fg colors
        self.style.configure("TButton", background="white", foreground="#0044cc", font=("Helvetica", 12, "bold"))
        self.style.configure("TLabel", background="#e6e6e6", foreground="black", font=("Helvetica", 12))
        self.style.configure("TFrame", background="#e6e6e6")
        self.style.configure("TCombobox", fieldbackground="white", background="white", font=("Helvetica", 12))

        # Load graph data
        graph = nodeinformation.graph_data()
        self.G = nx.Graph()
        for node in graph:
            for neighbor, weight, wheelchair in graph[node]:
                self.G.add_edge(node, neighbor, weight=weight, wheelchair=wheelchair)

        # Create UI elements
        self.create_input_panel()
        self.create_canvas()
        self.canvas_update_interval = 10

        self.selected_marker = None
        self.start_combo.bind("<<ComboboxSelected>>", lambda e: self.highlight_location(self.start_combo.get()))
        self.end_combo.bind("<<ComboboxSelected>>", lambda e: self.highlight_location(self.end_combo.get()))

    def create_input_panel(self):
        self.input_panel = ttk.Frame(self.root, padding="20")
        self.input_panel.grid(row=0, column=2, sticky="ns")
        
        locations = nodeinformation.locations()

        # Combo boxes for Start and End Points, Algorithm, Wheelchair with updated styles
        ttk.Label(self.input_panel, text="Start Node:", font=("Helvetica", 12)).grid(row=0, column=0, sticky="w", pady=5)
        self.start_combo = ttk.Combobox(self.input_panel, width=20, state="readonly", values=locations, font=("Helvetica", 12))
        self.start_combo.grid(row=0, column=1, pady=5)

        ttk.Label(self.input_panel, text="End Node:", font=("Helvetica", 12)).grid(row=1, column=0, sticky="w", pady=5)
        self.end_combo = ttk.Combobox(self.input_panel, width=20, state="readonly", values=locations, font=("Helvetica", 12))
        self.end_combo.grid(row=1, column=1, pady=5)

        ttk.Label(self.input_panel, text="Algorithm:", font=("Helvetica", 12)).grid(row=2, column=0, sticky="w", pady=5)
        self.algorithm_combo = ttk.Combobox(self.input_panel, width=20, state="readonly", values=["DFS", "BFS", "Dijkstra"], font=("Helvetica", 12))
        self.algorithm_combo.grid(row=2, column=1, pady=5)

        ttk.Label(self.input_panel, text="Wheelchair:", font=("Helvetica", 12)).grid(row=3, column=0, sticky="w", pady=5)
        self.wheelchair_combo = ttk.Combobox(self.input_panel, width=20, state="readonly", values=["No", "Yes"], font=("Helvetica", 12))
        self.wheelchair_combo.grid(row=3, column=1, pady=5)

        # Buttons with updated styles to match the design
        self.execute_button = ttk.Button(self.input_panel, text="Calculate Path", command=self.execute_algorithm)
        self.execute_button.grid(row=4, column=0, columnspan=2, pady=20, sticky="ew")

        # obstacle Generation Button
        self.obstacle_button = ttk.Button(self.input_panel, text="Create Obstacles", command=self.generate_obstacles)
        self.obstacle_button.grid(row=5, column=0, columnspan=2, pady=10, sticky="ew")

        # Clear button to reset
        self.clear_button = ttk.Button(self.input_panel, text="Clear", command=self.reset_canvas)
        self.clear_button.grid(row=6, column=0, columnspan=2, pady=10, sticky="ew")

        # Exit button placed below the Clear button
        self.exit_button = ttk.Button(self.input_panel, text="Exit", command=self.root.quit)
        self.exit_button.grid(row=7, column=0, columnspan=2, pady=10, sticky="ew")

        # Time label
        self.time_text = ttk.Label(self.input_panel, text="Time:", font=("Helvetica", 12))
        self.time_text.grid(row=8, column=0, columnspan=2, pady=5, sticky="ew")


    def create_canvas(self):
        # Close previous figure if it exists
        if hasattr(self, 'fig'):
            plt.close(self.fig)

        self.canvas_frame = ttk.Frame(self.root)
        self.canvas_frame.grid(row=0, column=1, sticky="nsew")

        graph = nodeinformation.graph_data()
        image = mpimg.imread("campus map.png")

        G = nx.Graph()
        for node in graph:
            for neighbor, weight, wheelchair in graph[node]:
                if weight < 999:
                    G.add_edge(node, neighbor, weight=weight, wheelchair=wheelchair)

        node_positions = nodeinformation.node_location()

        # Create a new figure with fixed size
        self.fig, self.ax = plt.subplots(figsize=(10, 10))  # Keep a fixed size

        nx.draw(G, node_positions, with_labels=False, node_size=0, node_color="aquamarine", ax=self.ax)

        for i, j, d in G.edges(data=True):
            if d["weight"] <= 999:
                nx.draw_networkx_edges(G, node_positions, edgelist=[(i, j)], ax=self.ax, edge_color="aquamarine", width=3.5)

        self.ax.imshow(image, extent=[0, 629, 0, 897], alpha=1)
        self.ax.axis("off")

        # Attach the figure to Tkinter canvas
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.canvas_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

    def execute_algorithm(self):
        start = self.start_combo.get()
        destination = self.end_combo.get()
        algorithm = self.algorithm_combo.get()

        # Determine wheelchair accessibility
        wheelchair = self.wheelchair_combo.get() == "Yes"

        if not start or not destination:
            messagebox.showwarning("Input Error", "Please select both a start and end point.")
            return
        elif not algorithm:
            messagebox.showwarning("Input Error", "Please select an algorithm.")
            return

        # Create a copy of the graph for modification
        graph = self.G.copy()

        # Adjust edge weights where weight >= 999
        for i, j, data in graph.edges(data=True):
            weight = data.get('weight', 1)
            if weight >= 999:
                # Modify the weight by dividing by a random number between 8 and 15
                new_weight = weight / randrange(8, 13)
                graph[i][j]['weight'] = new_weight

        # Use the modified graph for pathfinding
        node_positions = nodeinformation.node_location()

        # Call the appropriate algorithm with wheelchair parameter
        color = ''
        if algorithm == "BFS":
            weight, path = bfs.bfs(graph, start, destination, wheelchair)
            color = 'purple'
        elif algorithm == "DFS":
            weight, path = dfs.dfs(graph, start, destination, wheelchair)
            color = 'royalblue'
        elif algorithm == "Dijkstra":
            weight, path = dijkstra.dijkstra(graph, start, destination, wheelchair)
            color = 'slategray'

        # Convert weight to time
        time = round(weight * 0.000621371 / 3 * 60)

        self.time_text.config(text=f"Time: {time} minutes")

        # Change the color of the edges based on the path found
        ax = self.ax
        if path:
            edges_in_path = list(zip(path[:-1], path[1:]))  # Create a list of edges from the path

            # Draw only the edges that are part of the path
            for i, j in edges_in_path:
                # Draw the edge in purple
                nx.draw_networkx_edges(self.G, node_positions, ax=ax, edgelist=[(i, j)], edge_color=color, width=3.5)

        self.canvas.draw()

    def generate_obstacles(self):
        # Clear existing graph
        self.G.clear()
        graph = nodeinformation.graph_data()
        for node in graph:
            for neighbor, weight, wheelchair in graph[node]:
                self.G.add_edge(node, neighbor, weight=weight, wheelchair=wheelchair)

        # Iterate through all the edges of the graph and apply obstacle effects
        for i, j, data in self.G.edges(data=True):
            weight = data.get('weight', 1)  # Default to 1 if no weight is provided

            # Skip edges with weight 999 or greater
            if weight >= 999:
                continue

            # Generate a random obstacle factor between 1 and 15
            rand_num = randrange(1, 14)

            # Modify the edge weight based on the obstacle factor
            final_weight = weight * rand_num / 3

            # Assign edge color based on the new weight
            edge_color = 'lime' if 1 <= rand_num <= 9 else \
                         'gold' if 10 <= rand_num <= 11 else \
                         'peru' if 12 <= rand_num <= 13 else \
                         'darkred' if 13 <= rand_num <= 100 else \
                         'black'

            # Update the edge data with the new weight and color
            self.G[i][j]['weight'] = final_weight
            self.G[i][j]['color'] = edge_color

            # Now, also affect the nodes by adjusting their weight based on obstacle
            # If the edge weight is less than 999, adjust the nodes connected by this edge
            if weight < 999:
                for node in (i, j):
                    node_weight = self.G.nodes[node].get('weight', 1)
                    # Modify the node weight with a obstacle adjustment
                    # This assumes you want to adjust it similarly to how you do with the edges
                    self.G.nodes[node]['weight'] = node_weight / randrange(8, 13) if weight < 999 else node_weight

        # Clear the axes to ensure fresh drawing
        self.ax.cla()

        # Call the node position information
        node_positions = nodeinformation.node_location()

        # Draw the nodes and edges without drawing unwanted lines
        nx.draw(self.G, node_positions, with_labels=False, node_size=0, node_color="aquamarine", ax=self.ax, width=0)

        # Draw edges with updated colors, skipping the ones with weight >= 999
        for i, j, d in self.G.edges(data=True):
            if d["weight"] < 999:  # Only draw edges with valid weight
                edge_color = d.get("color", "aquamarine")  # Get the updated color
                nx.draw_networkx_edges(self.G, node_positions, edgelist=[(i, j)], ax=self.ax, width=3.5, edge_color=edge_color)

        # Overlay the campus map image
        image = mpimg.imread("campus map.png")
        self.ax.imshow(image, extent=[0, 629, 0, 897], alpha=1)
        self.ax.axis("off")  # Turn off axis

        # Update canvas
        self.canvas.draw()

        return self.G

    def highlight_location(self, location):
        node_positions = nodeinformation.node_location()
        if location in node_positions:
            x, y = node_positions[location]
            if self.selected_marker:
                self.selected_marker.remove()
            self.selected_marker = plt.Circle((x, y), radius=20, color="blue", alpha=0.5)
            self.ax.add_patch(self.selected_marker)
            self.canvas.draw()

    def reset_canvas(self):
        # Reset graph and UI
        self.G.clear()
        graph = nodeinformation.graph_data()
        for node in graph:
            for neighbor, weight, wheelchair in graph[node]:
                self.G.add_edge(node, neighbor, weight=weight, wheelchair=wheelchair)
        self.start_combo.set("")
        self.end_combo.set("")
        self.algorithm_combo.set("")
        self.wheelchair_combo.set("")
        self.time_text.config(text="Time: ")

        # Clear the current axes and redraw the initial state
        self.ax.cla()
        self.create_canvas()

if __name__ == "__main__":
    root = tk.Tk()
    app = CampusNavigationApp(root)
    root.mainloop()
