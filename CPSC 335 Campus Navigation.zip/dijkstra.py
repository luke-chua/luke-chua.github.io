import heapq
from random import randrange

def dijkstra(graph, source, destination, wheelchair=False):
    # Step 1: Initialize distances to infinity & set source distance
    distances = {node: float('inf') for node in graph}
    distances[source] = 0

    # Priority queue to store distance and node information
    priority_queue = [(0, source)]

    # Dictionary to keep track of the shortest path
    previous_nodes = {node: None for node in graph}

    # Step 2: While the priority queue is not empty, process each node
    while priority_queue:
        current_distance, current_node = heapq.heappop(priority_queue)

        # If we have reached the destination, break out of the loop
        if current_node == destination:
            break

        # If the current distance is already higher than the recorded one, skip it
        if current_distance > distances[current_node]:
            continue

        # Step 3: Check all the neighbors of the current node
        for neighbor, info in graph[current_node].items():
            weight = info['weight']
            accessible = info.get('wheelchair', 'No')  # Get wheelchair accessibility
            
            # If wheelchair accessibility is required, skip non-accessible paths
            if wheelchair and (accessible != 'Yes'):
                continue  # Skip non-accessible paths

            # Calculate new distance to the neighbor
            distance = current_distance + weight

            # If the new distance is shorter, update the distance and path
            if distance < distances[neighbor]:
                distances[neighbor] = distance
                previous_nodes[neighbor] = current_node
                heapq.heappush(priority_queue, (distance, neighbor))

    # Step 4: Reconstruct the shortest path from source to destination
    path = []
    current = destination
    while current is not None:
        path.append(current)
        current = previous_nodes[current]
    path.reverse()  # Reverse the path to start from the source node

    # Step 5: Return the shortest distance and path
    print(distances[destination], path)
    return distances[destination], path
