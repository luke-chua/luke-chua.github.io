#*****************************************************************************************************************************
# Program name: "Taylor Series".  Calculates the taylor series based on user input                                           *
#                                 and measures the run time of that operation                                                *
# Copyright (C) 2024  Luke Chua Marquez                                                                                      *
# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
# version 3 as published by the Free Software Foundation.                                                                    *
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied         *
# warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.     *
# A copy of the GNU General Public License v3 is available here:  <https://www.gnu.org/licenses/>.                           *
#*****************************************************************************************************************************
#========1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3=========4=========5=========6=========7**
# Author information
#  Author name : Luke Chua Marquez
#  Author email: luke.chua@csu.fullerton.edu
#  Author section: 240-19
#  Author CWID : 884834334
#
# Program information
# Program name: Taylor Series
#  Programming languages X86 with one modules in C
#  Date program began 2024-Nov-20
#  Date program completed 2024-Nov-26
#
# Purpose
#  This program will serve as practice to learn how to measure the run time of a block of code.
#
# Project information
#  Files: main.c, series.asm, taylor.asm, r.sh
#  Status: The program has been tested extensively with no detectable errors.
#
# Execution: ./go.out
#
#===== Begin code area ====================================================================================================================================================

echo "Remove old executable files if there are any"
rm *.out
rm *.o

echo "Assemble the X86 file series.asm"
nasm -f elf64 -l series.lis -o series.o series.asm

echo "Assemble the X86 file taylor.asm"
nasm -f elf64 -l taylor.lis -o taylor.o taylor.asm

echo "Compile the C++ file main.c"
gcc  -m64 -Wall -no-pie -o main.o -std=c2x -c main.c


echo "Link the three 'O' files taylor.o series.o main.o"
gcc -m64 -no-pie -o go.out taylor.o series.o main.o -std=c2x -Wall -z noexecstack


echo "Next the program ""Taylor Series"" will run"
chmod +x go.out
./go.out