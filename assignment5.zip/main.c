//*****************************************************************************************************************************
// Program name: "Taylor Series".  Calculates the taylor series based on user input                                           *
//                                 and measures the run time of that operation                                                *
// Copyright (C) 2024  Luke Chua Marquez                                                                                      *
// This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License  *
// version 3 as published by the Free Software Foundation.                                                                    *
// This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied         *
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.     *
// A copy of the GNU General Public License v3 is available here:  <https://www.gnu.org/licenses/>.                           *
//*****************************************************************************************************************************
//========1=========2=========3=========4=========5=========6=========7=========8=========9=========0=========1=========2=========3=========4=========5=========6=========7**
// Author information
//  Author name : Luke Chua Marquez
//  Author email: luke.chua@csu.fullerton.edu
//  Author section: 240-19
//  Author CWID : 884834334
//
// Program information
// Program name: Taylor Series
//  Programming languages X86 with one modules in C
//  Date program began 2024-Nov-20
//  Date program completed 2024-Nov-26
//
// Purpose
//  This program will serve as practice to learn how to measure the run time of a block of code.
//
// Project information
//  Files: main.c, series.asm, taylor.asm, r.sh
//  Status: The program has been tested extensively with no detectable errors.
//
// Execution: ./go.out
//
//===== Begin code area ====================================================================================================================================================

#include <stdio.h>

extern double series();  // Declaration of the external series function

int main() {
    // Display the welcome message
    printf("Welcome to Taylor Series by Luke Chua Marquez.\n");
    
    // Call series function which handles input/output
    double result = series();

    // Output from the main program (driver)
    printf("The driver received this number %.8lf and will keep it.\n", result);
    printf("Good-bye\n");

    return 0;
}
